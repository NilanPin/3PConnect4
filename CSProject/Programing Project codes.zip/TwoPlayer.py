# Libaries Needed
import numpy as np
import pygame
import math
import sys
import random
# RGB Values
BLUE = (0, 100, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
YELLOW = (255, 255, 0)
GREEN = (0, 200, 0)
WHITE = (255, 255, 255)
Highlight = (218,165,32)
# Row and Column Variables
ROWS = 8
COLUMNS = 9
# Freespace variable for is full
freespace = 0
# Player pieces Variable (To be outputted in the shell's board)
Player1 = 1
Player2 = 2
AI = 3
# Screen Size for our game
Screensize = 100
# Makes  our pygame window size
width = COLUMNS * Screensize
height = (ROWS + 1) * Screensize
size = (width, height)
# defines our counter size
Counter_Size = int(Screensize / 2 - 5)
# Turn variable to decide who go first
turn = random.randint(0, 2)

from pygame import mixer
mixer.init()
music = pygame.mixer.music.load("countersdrop.mp3")

# Inialises the board with 0's
def intialise_board():
    board = np.zeros((ROWS, COLUMNS))
    return board

# Creates the board and counters
def createboard(board):
    # Creates the connect 4 board makes it look orginal
    for c in range(COLUMNS):
        for r in range(ROWS):
            pygame.draw.rect(screen, BLUE, (c * Screensize, r * Screensize + Screensize, Screensize, Screensize))
            pygame.draw.circle(screen, BLACK, (
                int(c * Screensize + Screensize / 2), int(r * Screensize + Screensize + Screensize / 2)), Counter_Size)
    # Creates Red,Yellow,Green and Gold counters
    for c in range(COLUMNS):
        for r in range(ROWS):
            if board[r][c] == 1:
                pygame.draw.circle(screen, RED, (
                    int(c * Screensize + Screensize / 2), height - int(r * Screensize + Screensize / 2)), Counter_Size)
            elif board[r][c] == 2:
                pygame.draw.circle(screen, YELLOW, (
                    int(c * Screensize + Screensize / 2), height - int(r * Screensize + Screensize / 2)), Counter_Size)
            elif board[r][c] == 3:
                pygame.draw.circle(screen, GREEN, (
                    int(c * Screensize + Screensize / 2), height - int(r * Screensize + Screensize / 2)), Counter_Size)
            elif board[r][c] == 4:
                pygame.draw.circle(screen, Highlight, (
                    int(c * Screensize + Screensize / 2), height - int(r * Screensize + Screensize / 2)), Counter_Size)

    pygame.display.update()

def printboard(board):
    print(np.flip(board, 0))


# Drops a piece in the board shell so the one in pygame can be updated
def droppiece(board, row, col, piece):
    board[row][col] = piece

def isvalid(board, col):
    return board[ROWS - 1][col] == 0


def nextrow(board, col):
    for r in range(ROWS):
        if board[r][col] == 0:
            return r

def winningpos(board, piece):
    # Check horizontal locations for win
    for c in range(COLUMNS - 3):
        for r in range(ROWS):
            if board[r][c] == piece and board[r][c + 1] == piece and board[r][c + 2] == piece and board[r][
                c + 3] == piece:
                piece = 4
                board[r][c] = piece
                board[r][c+1] = piece
                board[r][c+2] = piece
                board[r][c+3] = piece
                return True

    # Check vertical locations for win
    for c in range(COLUMNS):
        for r in range(ROWS - 3):
            if board[r][c] == piece and board[r + 1][c] == piece and board[r + 2][c] == piece and board[r + 3][
                c] == piece:
                piece = 4
                board[r][c] = piece
                board[r + 1][c] = piece
                board[r + 2][c] = piece
                board[r + 3][c] = piece
                return True

    # Check positively sloped diagonal
    for c in range(COLUMNS - 3):
        for r in range(ROWS - 3):
            if board[r][c] == piece and board[r + 1][c + 1] == piece and board[r + 2][c + 2] == piece and board[r + 3][
                c + 3] == piece:
                piece = 4
                board[r][c] = piece
                board[r + 1][c + 1] = piece
                board[r + 2][c + 2] = piece
                board[r + 3][c + 3] = piece
                return True

    # Check negatively sloped diagonal
    for c in range(COLUMNS - 3):
        for r in range(3, ROWS):
            if board[r][c] == piece and board[r - 1][c + 1] == piece and board[r - 2][c + 2] == piece and board[r - 3][
                c + 3] == piece:
                piece = 4
                board[r][c] = piece
                board[r - 1][c + 1] = piece
                board[r - 2][c + 2] = piece
                board[r - 3][c + 3] = piece
                return True


def isfull(board, freespace):
    for x in range(0, (COLUMNS)):
        if board[ROWS - 1][x] == 0:
            freespace = freespace + 1
    if freespace == 0:
        return True


def setscores(window, piece):
    score = 0

    if window.count(piece) == 3 and window.count(0) == 1:
        score += 500
    elif window.count(piece) == 2 and window.count(0) == 2:
        score += 200

    if window.count(Player1) == 3 and window.count(0) == 1:
        score -= 400

    if window.count(Player2) == 3 and window.count(0) == 1:
        score -= 400

    return score


def counter_window(board, piece):
    score = 0

    # Score center column
    center = [int(i) for i in list(board[:, COLUMNS // 2])]
    count = center.count(piece)
    score = count * 3

    # Score Horizontal
    for r in range(ROWS):
        rowarray = [int(i) for i in list(board[r, :])]
        for c in range(COLUMNS - 3):
            window = rowarray[c:c + 4]
            score += setscores(window, piece)

    # Score Vertical
    for c in range(COLUMNS):
        colarray = [int(i) for i in list(board[:, c])]
        for r in range(ROWS - 3):
            window = colarray[r:r + 4]
            score += setscores(window, piece)

    # Score positive sloped diagonal
    for r in range(ROWS - 3):
        for c in range(COLUMNS - 3):
            window = [board[r + i][c + i] for i in range(4)]
            score += setscores(window, piece)
    # Score Negative sloped diagonals
    for r in range(ROWS - 3):
        for c in range(COLUMNS - 3):
            window = [board[r + 3 - i][c + i] for i in range(4)]
            score += setscores(window, piece)

    return score


# Works out if any given state resulted in a win for any of the players/AI or if its full
def endnode(board):
    return winningpos(board, Player1) or winningpos(board, Player2) or winningpos(board, AI) or \
           isfull(board,freespace) == True

def AvailablePos(board):
    Available = []
    for col in range(COLUMNS):
        if isvalid(board, col):
            Available.append(col)
    return Available


def minimax(board, depth, alpha, beta, playerturn):
    # Generates all valid moves stores them to array valid moves
    validmoves = AvailablePos(board)
    # will give terminal a boolean value based on the state of a board.
    terminal = endnode(board)
    # Checks if depth is 0 or terminal is True
    if depth == 0 or terminal:
        # Assigns heuristic values
        if terminal:
            if winningpos(board, AI):
                return (None, 1000)
            elif winningpos(board, Player1) or winningpos(board,Player2):
                return (None,-1000)
            else:  # Game is over, no more valid moves
                return (None, 0)
        else:  # Depth is zero
            return (None, counter_window(board, AI))

    # Player 1 Minimising tree creation
    if playerturn == 0:
        value = math.inf
        # Drops a counter in every valid location
        for col in validmoves:
            row = nextrow(board, col)
            new_board = board.copy()
            droppiece(new_board, row, col, 1)
            # Stops creation if player has won and makes sure depth is three
            #  further depths is unneeded and it ensures the player can win on their next turn not further turns
            if winningpos(new_board,1) and depth == 3:
                column = col
                value = -10000
                return column, value
            # Recursion
            newvalue = minimax(new_board, depth - 1, alpha, beta, 1)[1]
            if newvalue < value:
                value = newvalue
                column = col
                # Pruning redundant/unneeded states
            beta = min(beta, value)
            if alpha >= beta:
                break
        return column, value

    # Player 2 minimising tree creation
    elif playerturn == 1:
        value = math.inf
        # Drops a counter in every valid locations
        for col in validmoves:
            row = nextrow(board, col)
            new_board = board.copy()
            droppiece(new_board, row, col, 2)
            # Stops creation if player has won and makes sure depth is two
            #  further depths is unneeded and it ensures the player can win on their next turn not further turns
            if winningpos(new_board,2) and depth == 2:
                column = col
                value = -10000
                return column, value
            # Recursion
            newvalue = minimax(new_board, depth - 1, alpha, beta, 2)[1]
            if newvalue < value:
                value = newvalue
                column = col
            # Pruning redundant/unneeded states
            beta = min(beta, value)
            if alpha >= beta:
                break
        return column, value

    # AI's maximising tree creation
    elif playerturn == 2:
        value = -math.inf
        # Drops a counter in all valid locations
        for col in validmoves:
            row = nextrow(board, col)
            new_board = board.copy()
            droppiece(new_board, row, col, AI)
            # Stops creation if the AI can win on this turn
            if winningpos(new_board,AI) and depth == 4:
                column = col
                value = 10000
                return column, value
            # Recursion
            newvalue = minimax(new_board, depth - 1, alpha, beta, 0)[1]
            if newvalue > value:
                value = newvalue
                column = col
                # Pruning
            alpha = max(alpha, value)
            if alpha >= beta:
                break
        return column, value



board = intialise_board()
printboard(board)
game_over = False

pygame.init()

screen = pygame.display.set_mode(size)
createboard(board)
pygame.display.update()

myfont = pygame.font.SysFont("monospace", 75)

while not game_over:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()

        if event.type == pygame.MOUSEMOTION:
            pygame.draw.rect(screen, WHITE, (0, 0, width, Screensize))
            posx = event.pos[0]
            if turn == 0:
                pygame.draw.circle(screen, RED, (posx, int(Screensize / 2)), Counter_Size)
            elif turn == 1:
                pygame.draw.circle(screen, YELLOW, (posx, int(Screensize / 2)), Counter_Size)
        pygame.display.update()

        if event.type == pygame.MOUSEBUTTONDOWN:
            pygame.draw.rect(screen, WHITE, (0, 0, width, Screensize))

            # Ask for Player 1 Input
            if turn == 0 and not game_over:
                posx = event.pos[0]
                col = int(math.floor(posx / Screensize))

                if isvalid(board, col):
                    row = nextrow(board, col)
                    droppiece(board, row, col, 1)
                    pygame.mixer.music.play(1)

                    if winningpos(board, 1):
                        label = myfont.render("  Player 1 wins!!   ", 1, RED)
                        screen.blit(label, (40, 10))
                        game_over = True
                    else:
                        if isfull(board, freespace) == True:
                            label = myfont.render("   IT IS A DRAW  ", 1, BLUE)
                            screen.blit(label, (40, 10))
                            game_over = True
                        else:
                            turn = 1
                    printboard(board)
                    createboard(board)

            # # Ask for Player 2 Input
            elif turn == 1 and not game_over:

                posx = event.pos[0]
                col = int(math.floor(posx / Screensize))

                if isvalid(board, col):
                    row = nextrow(board, col)
                    droppiece(board, row, col, 2)
                    pygame.mixer.music.play(1)

                    if winningpos(board, 2):
                        label = myfont.render("  Player 2 wins!!   ", 1, YELLOW)
                        screen.blit(label, (40, 10))
                        game_over = True
                    else:
                        if isfull(board, freespace) == True:
                            label = myfont.render("     IT IS A DRAW!!!     ", 1, BLUE)
                            screen.blit(label, (40, 10))
                            game_over = True
                        else:
                            turn = 2
                    printboard(board)
                    createboard(board)

    if turn == 2 and not game_over:
        randommove = random.randint(1,10)
        if randommove < 3:
            Avaliablemoves = AvailablePos(board)
            col = random.choice(Avaliablemoves)

        else:
            col, minimax_score = minimax(board, 4, -math.inf, math.inf, 2)

        if isvalid(board, col):
            row = nextrow(board, col)
            droppiece(board, row, col, 3)
            pygame.mixer.music.play(1)

            if winningpos(board, 3):
                label = myfont.render("     AI wins!!       ", 1, GREEN)
                screen.blit(label, (40, 10))
                game_over = True
            else:
                if isfull(board, freespace) == True:
                    label = myfont.render("     IT IS A DRAW!!!     ", 1, BLUE)
                    screen.blit(label, (40, 10))
                    game_over = True
                else:
                    turn = 0
        printboard(board)
        createboard(board)

    if not game_over:
        continue
    pygame.time.wait(9000)

